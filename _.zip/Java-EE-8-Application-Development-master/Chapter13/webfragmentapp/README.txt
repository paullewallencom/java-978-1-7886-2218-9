Project webfragmentlib must be built before this project in order for this project to build successfully.

Before attempting to build this project, change directory to webfragmentlib and do an "mvn install".
