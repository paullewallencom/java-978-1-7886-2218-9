# Java-EE-8-Application-Development-Code-Samples
Code samples for the book [Java EE 8 Application Development](https://www.packtpub.com/application-development/java-ee-8-application-development) by David R. Heffelfinger, to be published by [Packt Publishing](http://www.packtpub.com)

Chapter 5 covers Contexts and Dependency Injection (CDI).
