package net.ensode.javaee8book.jsfwebsocket.config;

import javax.faces.annotation.FacesConfig;

@FacesConfig(version = FacesConfig.Version.JSF_2_3)
public class ConfigurationBean {

}
